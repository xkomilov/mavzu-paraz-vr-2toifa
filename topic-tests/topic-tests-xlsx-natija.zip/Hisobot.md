# Hisobot: parazitologiya mavzu testlari (topic-test-xlsx)

## Natija

- Manba: `Mavzu-paraz-vr-II.zip` (test-parazitologiya repo), 149 ta mavzu (001–149).
- Natija: `natija/NNN.xlsx`, 149 fayl. Shablon: 4 javobli `shablon.xlsx`.
- Savollar: jami 1495. Har faylda 10 yoki 11 savol.
- Qat'iy QA (`build_tests.js --check`): 0 xato. Hammasi `.xlsx` ga yozildi.
- Qayta o'qish (jszip): 149 fayl, har biri 10–11 savol, 4 variant, izohda mavzu matnidan iqtibos.

## To'g'ri javob taqsimoti

| Harf | Savollar soni |
|---|---|
| A | 374 |
| B | 370 |
| C | 373 |
| D | 378 |

## Ogohlantirishlar

- Qat'iy tekshiruvdan o'tgan, lekin ogohlantirish berilgan savollar: 217 ta, 120 ta mavzuda.
- Ogohlantirish turi: to'g'ri javob noto'g'ri javobdan 10% dan ortiq uzun. Fayllarni yozishni to'xtatmaydi, lekin test sifatiga ta'sir qilishi mumkin.

## Tasdiqlanmagan faktlar

- Manba matnida `[tasdiqlanmagan]` belgisi bor 109 ta mavzu bor.
- Savollarning birortasi ham bunday faktni to'g'ri javob, variant yoki iqtibos sifatida ishlatmagan (0 ta).

## Ko'rib chiqish talab qilinadi

- Tibbiy mazmun (dozalar, me'yorlar, muddatlar) parazitologiya bo'yicha mutaxassis tomonidan tekshirilishi kerak. Skript faqat matn mosligini tekshiradi, tibbiy to'g'riligini emas.
- Ba'zi noto'g'ri variantlar savolga mantiqan zaif (masalan, 099 S9, 101 S8, 119 S9, 121 S10, 131 da "Bolalarning 80 foizida"). Ularni qo'lda o'qib tuzatish tavsiya etiladi.
- Ko'p savollarda noto'g'ri variantlar 70% so'z moslik qoidasini bajarish uchun mavzu matnidan olingan. Ularning ba'zilari mantiqiy jihatdan sust.
- Qo'shimcha adabiyot (xayrullokomilov.uz/kutubxona, internet) bu bosqichda ishlatilmadi. Skill savol matnini faqat mavzu matnidan olishni talab qiladi.

## Ishlatilgan skill va fayllar

- `topic-test-xlsx` (SKILL.md, `extract_txt.js`, `build_tests.js`).
- `test-question-writing` (savol yozish qoidalari).
- `shablon.xlsx` (test-parazitologiya repo).
- Ish papkasi `_build/` (matnlar, savol JSON fayllari, skriptlar).
